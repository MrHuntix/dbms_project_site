<?php
	require 'dbase.php';
	include 'login.php';
	$user_check=$_SESSION['username'];
	//$user_id=$_SESSION['cust_id'];
	$GLOBALS['movie_error']=" ";
?>