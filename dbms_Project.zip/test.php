<?php
	$today=strtotime(date('Y/m/d'));
	$yest=strtotime('2016/12/2');
	echo "today".$today;
	echo "<br>yesterday".$yest;

?>